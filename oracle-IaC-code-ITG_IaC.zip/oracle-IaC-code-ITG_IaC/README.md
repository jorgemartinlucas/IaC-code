# Mercadona - Solución Infrastructure as Code

## How to clone repository
Run the following code:

`
mkdir $HOME/YOUR_USERNAME
cd $HOME/YOUR_USERNAME
git init
git config user.name "YOUR_USERNAME"
git config user.email "YOUR EMAIL"
git clone http://iacgit.itg.mercadona.es/mercadona/oracle-IaC-code.git
git checkout ITG_IaC`

## Cheatsheet
Run Ansible playbook:
`ansible-playbook -i inventories/<Environment> --vault-password-file passwd.file.txt <playbook.yml>`

Show Ansible facts:
`ansible -i inventories/<Environment> all|<group> -m setup
`

## Basic concepts
1. Inventories
2. Playbooks
3. Password Vaults

//TODO

## Using SSH

1. You should create a sshkey using ssh-keygen command https://docs.gitlab.com/ee/gitlab-basics/create-your-ssh-keys.html
2. Step (1) created two files, the file with pub extension should be imported in git (ssh keys)
3. Some additional configuration is needed. In the home directory under .ssh directory. This configuration allows to create ssh passwordless sessions and interact with git using ssh. 

```
Host gitserver
  Hostname iacgit.itg.mercadona.es
  IdentityFile ~/.ssh/id_rsa
  RSAAuthentication yes
  User git

```

4. Using the previous configuration, git commands could be as follow:

```
git clone gitserver:mercadona/oracle-IaC-code.git
git add -all
git push origin ITG_IaC
```

5. Additionally, you should enable ssh access to user git. As root, add the line to /etc/security/access.conf where the user git appears. Git operations won't work propertly if this step is ommited.

```
+ : root : LOCAL
+ : gar : ALL
+ : mft : ALL
+ : expl : ALL
+ : simpana : ALL
+ : git : ALL
+ : (dba) : ALL
+ : (allowed_local) : ALL
+ : (InternosLinuxInventario) : ALL
+ : (ExternosLinuxSistemas) : ALL
+ : (InternosLinuxSistemas) : ALL
+ : (ExternosLinuxExpl) : ALL
+ : (InternosLinuxExpl) : ALL
+ : (ExternosLinuxExplOra) : ALL
```

