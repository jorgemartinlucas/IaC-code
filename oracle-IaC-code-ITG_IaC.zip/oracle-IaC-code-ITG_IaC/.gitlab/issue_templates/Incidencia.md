**Entorno:** (ejemplo: PRO/PRE/ITG/MIG)

**Playbook:** (ejemplo: db-deploy-cl01cpdd1.yml)

**Rol:** (ejemplo: db_db_configure)

**Play:** (ejemplo: generate_tnsnames.ora)

**Task:** (ejemplo: Add Database TNS entry)


## Problema:

## Situación esperada:

## Posibles soluciones:

## Comentarios:


